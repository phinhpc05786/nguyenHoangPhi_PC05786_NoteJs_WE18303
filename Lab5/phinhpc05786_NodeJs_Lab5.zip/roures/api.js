const express = require("express");
const multer = require("multer");
const ProductController = require("../controller/api/ProductControllers");
const router = express.Router();
const upload = multer({ dest: "./public/data/uploads/" });


router.get("/products", ProductController.getProducts); // lấy bài viết
router.post("/products", upload.single("img"), ProductController.postProducts);
// router.get('/posts/:id', ProductController.getPosts); // lấy 1 bài
// router.post('/posts', ProductController.getPosts); // thêm dữ liệu
// router.put('/posts/:id', ProductController.getPosts); // sửa tất cả field
// router.patch('/posts/:id', ProductController.getPosts); // sửa 1 hoặc một vài dữ liệu
// router.delete('/posts/:id', ProductController.getPosts); // xóa

module.exports = router;
