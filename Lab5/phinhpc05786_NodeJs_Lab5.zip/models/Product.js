const connection = require("./Database.js");

let products = [];
module.exports = class Product {
  constructor() {}

  static getAll(callback) {
    let sql = "SELECT * FROM products";
    connection.query(sql, function (err, data) {
      if (err) throw err;
      callback(data);
    });
  }

  static getAll(id, callback) {
    let sql = `SELECT * FROM products where id = ${id}`;
    connection.query(sql, function (err, data) {
      if (err) throw err;
      callback(data);
    });
  }



  static create(newProduct, callback) {
    connection.query("INSERT INTO products SET ?", newProduct, (err, result) => {
        if (err) {
            callback(err, null);
        } else {
            callback(null, newProduct);
        }
    });
}

  // static getAllProduct() {
  //   return new Promise(function (resolve, reject) {
  //     const query = "SELECT * FROM products";
  //     connection.query(query, (err, results) => {
  //       if (err) {
  //         reject(err);
  //         return;
  //       }
  //       resolve(results);
  //     });
  //   });
  // }

  // static getAllPosts() {
  //   return new Promise(function (resolve, reject) {
  //     const query = "SELECT * FROM posts";
  //     connection.query(query, (err, results) => {
  //       if (err) {
  //         reject(err);
  //         return;
  //       }
  //       resolve(results);
  //     });
  //   });
  // }
};
