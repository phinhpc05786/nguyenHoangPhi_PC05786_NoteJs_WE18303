const Product = require("../../models/Product");

// exports.addProduct = (req, res, next) => {
//   res.render("admin/product/add");
// };

exports.getProducts = (req, res, next) => {
  Product.getAll(function (products) {
    res.status(200).json({
      messages: "Product list",
      data: products
    });
  });
};

exports.postProducts = (req, res, next) => {
  let products = {
    name: req.body.name,
    price: req.body.price,
    description: req.body.description,
    cate: req.body.cate,
    img: req.body.img
  }
  Product.create(products, function (result){
    res.status(201).json({
      data:result
    })
  })
};

// exports.postProduct = (req, res, next) => {
//   const newProduct = req.body; 
//   res.status(200).json({
//     message: "Product created successfully",
//     data: newProduct
//   });
// };
